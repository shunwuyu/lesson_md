[source](https://www.cnblogs.com/zhaowinter/p/10776868.html)

-  main.js 限制访问次数
