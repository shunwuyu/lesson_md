# -*- coding: utf8 -*-


def main_handler(event, context):
    print(str(event))
    return "hello world"

