<template>
  <div class="look">{{mseeage}}</div>
</template>

<script>
export default {
  name: 'Look',
  data () {
    return {
      mseeage: '你瞅啥？'
    }
  }
}
</script>

<style scoped>
.look{
  font-size: 26px;
}
</style>
