const defaultState = {
    singers: [
        {id:1, name: '王力宏'}, 
        {id:2, name: '周比畅'}, 
    ]
}
const reducer = (state=defaultState) => {
    return state
}

export default reducer