import { useState } from 'react'
import Notes from './components/Notes'

function App() {
  return <Notes />
}

export default App
