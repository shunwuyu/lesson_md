Component({
  options: {
    addGlobalClass: true
  },

  externalClasses: ['custom-class'],

  properties: {
    type: String,
    mark: Boolean,
    plain: Boolean
  }
});
