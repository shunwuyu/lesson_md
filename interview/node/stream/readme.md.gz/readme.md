https://juejin.im/post/5a4a377151882546f00a68c9

- node.js 中最好也最难理解的概念


Streams是Node.js最重要的组件和模式之一
Stream all the things（Steam就是所有的）
与性能或效率等技术特性有关
它们的优雅性  es6


