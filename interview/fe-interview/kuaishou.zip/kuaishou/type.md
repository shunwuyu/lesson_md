数字 字符串 null undefined boolean symbol
对象