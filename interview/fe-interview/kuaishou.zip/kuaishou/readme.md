- [无穷大](https://www.cnblogs.com/wujidns/p/5781084.html)


- [去重](https://juejin.im/post/5949d85f61ff4b006c0de98b)
- [类型判断](https://github.com/shunwuyu/lesson_show/blob/468c476cf7e9b2a72754db10d8ca5d79f8d2f026/js/type_test/4.js)
- [垃圾回收](https://segmentfault.com/a/1190000018605776?utm_source=tag-newest)
