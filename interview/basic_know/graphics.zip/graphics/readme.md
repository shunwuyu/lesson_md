[source](https://juejin.cn/post/7033615049721806879#heading-2)

- canvas 用来干嘛的？
    canvas是HTML5提供的一种新标签。
    画布是一个矩形区域，您可以控制其每一像素。
    js API   
    数据可视化， 游戏 

    canvas/1.html  rotate 

- WebGL与Threejs工作原理
    Web Graphics Library 3D绘图协议 JavaScript和OpenGL ES 2.0结合在一起，通过增加OpenGL ES 2.0的一个JavaScript绑定，WebGL可以为HTML5 Canvas提供硬件3D加速渲染，这样Web开发人员就可以借助系统显卡来在浏览器里更流畅地展示3D场景和模型了，还能创建复杂的导航和数据视觉化。
    three.js库可以简化这个过程。
    webgl/1.html


