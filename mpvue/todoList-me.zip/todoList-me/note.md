## mpvue
1.  Vue.js 的小程序开发框架
2.  微信小程序、百度智能小程序，头条小程序 和 支付宝小程序
3.  为小程序开发引入了 Vue.js 开发体验
   
## 小程序

1. 目录结构和往常的不一样 没 app.js app.json 怎么运行起来？
miniprogramRoot：指定小程序源码的目录
目录结构被 mpvue 定制化

2. Vue 的语法
模版： html + 小程序
js： wxjs + Vue.js

