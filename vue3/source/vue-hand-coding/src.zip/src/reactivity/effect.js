export function effect(fn) {
}

export function track() {
}

export function trigger() {
}