// const { reactive, effect } = require('@vue/reactivity')
import { reactive } from '../reactive'
import { effect } from '../effect'
// jest 提供api 
// vue 达成了 99.99% 用例测试的框架
describe('测试响应式', () => {
    // item 上一个测试用例
    it('测试', () => {
        // expect  toBe 断言 
        expect(1 + 2).toBe(3)
    })
    it('reative 基本使用', () => {
        // expect(1 + 2).toBe(3)
        const ret = reactive({num: 0})
        let val
        effect(() => {
            val = ret.num // 运行 依赖收集
        })
        expect(val).toBe(0)
        // ret.num++
        // expect(val).toBe(1)
        // ret.num = 10
        // expect(val).toBe(10)
    })
})

