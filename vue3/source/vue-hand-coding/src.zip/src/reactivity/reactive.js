// ? vue 依赖关系是用"对象"来组织的  key 对象， map更适合， 
// 组件的卸载， WeakMap 自动的删除  弱引用  垃圾回收
// 为了依赖函数的查找， 更新的时候， 找依赖 vuex 单一状态树 targetMap 依赖图谱
// const ret = reactive({num: 0, num1: 2, num2: {a: 2}})  // 深代理
import { mutableHandlers } from './baseHandlers'
export const reactiveMap = new WeakMap()
// 响应式
export function reactive(target) {
    // 修改后， 如何处理
    return createReactiveObject(target, reactiveMap, mutableHandlers)
} 

function createReactiveObject(target, proxyMap, proxyHandlers) {
    const proxy = new Proxy(target, proxyHandlers)
    proxyMap.set(target, proxy)
    return proxy
}