const get = () => {}
const set = () => {}
const has = () => {}
const deleteProperty = () => {}
export const mutableHandlers = {
    get,
    set ,
    has,
    deleteProperty
}