const UserModel = require("./user")
const QRCodeModel = require("./qrcode")

module.exports = {
  UserModel,
  QRCodeModel
}