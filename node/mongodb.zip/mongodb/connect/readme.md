[source](https://www.runoob.com/nodejs/nodejs-mongodb.html)
mongod --config /usr/local/etc/mongod.conf --dbpath /data/db
- mongod
  mongo
  